import React from 'react';
import { User, Bot, ExternalLink } from 'lucide-react';

export interface Message {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: Date;
  citations?: Citation[];
}

export interface Citation {
  source: string;
  section: string;
  page?: number;
}

interface ChatMessageProps {
  message: Message;
}

const ChatMessage: React.FC<ChatMessageProps> = ({ message }) => {
  const isUser = message.type === 'user';

  return (
    <div className={`flex ${isUser ? 'justify-end' : 'justify-start'} mb-6`}>
      <div className={`flex max-w-4xl ${isUser ? 'flex-row-reverse' : 'flex-row'} items-start space-x-3`}>
        {/* Avatar */}
        <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${
          isUser ? 'bg-fire-600 ml-3' : 'bg-gray-600 mr-3'
        }`}>
          {isUser ? (
            <User className="h-5 w-5 text-white" />
          ) : (
            <Bot className="h-5 w-5 text-white" />
          )}
        </div>

        {/* Message Content */}
        <div className={`rounded-2xl px-6 py-4 shadow-sm ${
          isUser 
            ? 'bg-fire-600 text-white' 
            : 'bg-white text-gray-900 border border-gray-200'
        }`}>
          <div className="whitespace-pre-wrap text-sm leading-relaxed">
            {message.content}
          </div>

          {/* Citations */}
          {message.citations && message.citations.length > 0 && (
            <div className="mt-4 pt-4 border-t border-gray-200">
              <div className="text-xs font-medium text-gray-600 mb-2">References:</div>
              <div className="space-y-1">
                {message.citations.map((citation, index) => (
                  <div key={index} className="flex items-center space-x-2 text-xs text-gray-600">
                    <ExternalLink className="h-3 w-3" />
                    <span>
                      <strong>{citation.source}</strong> - {citation.section}
                      {citation.page && ` (Page ${citation.page})`}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Timestamp */}
          <div className={`text-xs mt-2 ${
            isUser ? 'text-fire-100' : 'text-gray-500'
          }`}>
            {message.timestamp.toLocaleTimeString()}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;