
import React from 'react';
import { useAuth } from '../contexts/AuthContext';

const AuthControls = () => {
  const { user, login, logout } = useAuth();

  return (
    <div className="text-sm flex gap-2 items-center">
      {user ? (
        <>
          <span className="text-gray-300">Hello, {user.name}</span>
          <button onClick={logout} className="bg-red-600 hover:bg-red-700 px-3 py-1 rounded text-white">
            Logout
          </button>
        </>
      ) : (
        <>
          <button onClick={() => login('guest')} className="bg-blue-600 hover:bg-blue-700 px-3 py-1 rounded text-white">
            Login as Guest
          </button>
          <button onClick={() => login('admin')} className="bg-green-600 hover:bg-green-700 px-3 py-1 rounded text-white">
            Login as Admin
          </button>
        </>
      )}
    </div>
  );
};

export default AuthControls;
