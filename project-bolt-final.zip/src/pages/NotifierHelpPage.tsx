import React, { useState } from 'react';
import { Search, Wrench, AlertTriangle, BookOpen, Zap, Cpu, Settings2 } from 'lucide-react';
import SearchBar from '../components/SearchBar';
import ChatMessage, { Message } from '../components/ChatMessage';

interface TroubleshootingGuide {
  id: string;
  title: string;
  category: string;
  icon: React.ComponentType<any>;
  description: string;
  steps: string[];
  relatedManual: string;
}

const NotifierHelpPage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('all');

  const categories = [
    { value: 'all', label: 'All Categories' },
    { value: 'programming', label: 'Programming' },
    { value: 'wiring', label: 'Wiring & Installation' },
    { value: 'troubleshooting', label: 'Troubleshooting' },
    { value: 'maintenance', label: 'Maintenance' },
    { value: 'slc', label: 'SLC Loops' },
    { value: 'nac', label: 'NAC Circuits' }
  ];

  const troubleshootingGuides: TroubleshootingGuide[] = [
    {
      id: '1',
      title: 'SLC Loop Fault Troubleshooting',
      category: 'troubleshooting',
      icon: AlertTriangle,
      description: 'Step-by-step guide to diagnose and resolve SLC loop communication issues',
      steps: [
        'Check the display for specific loop trouble indicators',
        'Verify loop wiring integrity using a multimeter',
        'Check for proper loop termination (EOL resistor)',
        'Test individual device addresses for conflicts',
        'Inspect wiring for shorts, opens, or ground faults',
        'Verify proper device polarization on Class A loops'
      ],
      relatedManual: 'NFS2-3030 Installation Manual, Section 3.4'
    },
    {
      id: '2',
      title: 'Device Programming on NFS2-3030',
      category: 'programming',
      icon: Cpu,
      description: 'Complete guide for programming devices on Notifier NFS2-3030 panels',
      steps: [
        'Enter programming mode: Hold ACK + SILENCE for 3 seconds',
        'Enter access code (default: 1, 2, 3, 4)',
        'Navigate to Device Programming menu',
        'Select SLC loop number (1-2)',
        'Enter device address (001-159)',
        'Choose device type from the dropdown menu',
        'Enter descriptive label (up to 20 characters)',
        'Save configuration and verify with walk test'
      ],
      relatedManual: 'NFS2-3030 Programming Manual, Chapter 4'
    },
    {
      id: '3',
      title: 'NAC Circuit Configuration',
      category: 'programming', 
      icon: Zap,
      description: 'Setting up Notification Appliance Circuits for optimal performance',
      steps: [
        'Access NAC programming menu from main display',
        'Select NAC circuit number (1-4)',
        'Configure circuit type (Class A or Class B)',
        'Set power requirements and supervision',
        'Program activation patterns and timing',
        'Test circuit integrity and appliance operation',
        'Document circuit layout and device locations'
      ],
      relatedManual: 'NFS2-3030 Installation Guide, Section 5.2'
    },
    {
      id: '4',
      title: 'Loop Wiring Best Practices',
      category: 'wiring',
      icon: Settings2,
      description: 'Professional installation techniques for SLC loop wiring',
      steps: [
        'Use approved fire alarm cable (FPLR or FPLP)',
        'Maintain proper wire gauge for loop length',
        'Install EOL resistor at the end of Class B loops',
        'Return wiring to panel for Class A configuration',
        'Avoid running loops near power conductors',
        'Test loop resistance and verify within specifications',
        'Label all wiring clearly for future maintenance'
      ],
      relatedManual: 'Notifier Installation Guidelines, Chapter 2'
    }
  ];

  const filteredGuides = selectedCategory === 'all' 
    ? troubleshootingGuides 
    : troubleshootingGuides.filter(guide => guide.category === selectedCategory);

  const simulateNotifierResponse = (query: string): Promise<{ content: string; citations: any[] }> => {
    return new Promise((resolve) => {
      setTimeout(() => {
        let response = {
          content: '',
          citations: [
            { source: 'Notifier NFS2-3030 Manual', section: 'Programming Guide', page: 67 }
          ]
        };

        if (query.toLowerCase().includes('program') || query.toLowerCase().includes('device')) {
          response.content = `To program devices on the Notifier NFS2-3030:

**Access Programming Mode:**
1. Press and hold ACKNOWLEDGE + SIGNAL SILENCE for 3 seconds
2. Enter your access code (default: 1, 2, 3, 4)
3. Select "Program" from the main menu

**Device Programming Steps:**
1. Navigate to "Device" in the programming menu
2. Select the SLC loop number (1 or 2)
3. Enter device address (001-159)
4. Choose device type from the list:
   - Smoke Detectors (Various models)
   - Heat Detectors
   - Manual Pull Stations
   - Module Devices
5. Enter device label (up to 20 characters)
6. Configure device-specific settings if applicable
7. Save the configuration

**Verification:**
Always perform a walk test after programming to verify proper device operation and communication.`;
          
        } else if (query.toLowerCase().includes('slc') || query.toLowerCase().includes('loop')) {
          response.content = `SLC Loop Configuration on Notifier Systems:

**Loop Types:**
- **Class A (Style 6 or 7):** Provides redundant path with return wiring
- **Class B (Style 4):** Single path with end-of-line resistor

**Configuration Steps:**
1. Access SLC menu in programming mode
2. Select loop number (1-2 on NFS2-3030)
3. Choose loop class and style
4. Set loop power (normal or high power)
5. Configure loop timing parameters

**Troubleshooting SLC Issues:**
- Check EOL resistor (47kΩ for Class B)
- Verify wiring integrity with multimeter
- Look for ground faults or shorts
- Confirm proper device addressing`;
          response.citations = [
            { source: 'NFS2-3030 Installation Manual', section: 'SLC Configuration', page: 78 },
            { source: 'Notifier Loop Wiring Guide', section: 'Class A/B Setup', page: 23 }
          ];

        } else if (query.toLowerCase().includes('nac') || query.toLowerCase().includes('notification')) {
          response.content = `NAC Circuit Programming:

**NAC Circuit Types:**
- Steady outputs for horns/strobes
- Temporal patterns for evacuation
- Custom patterns for special applications

**Programming Steps:**
1. Access NAC programming menu
2. Select circuit number (1-4)
3. Configure circuit characteristics:
   - Class A or Class B
   - Power requirements
   - Supervision type
4. Set activation patterns
5. Program timing sequences
6. Test circuit operation

**Current Calculations:**
Ensure total NAC load doesn't exceed panel capacity. Use current ratings from device data sheets.`;

        } else {
          response.content = `I can help with Notifier system programming, troubleshooting, and installation questions. Try asking about:

- Device programming procedures
- SLC loop configuration
- NAC circuit setup
- Troubleshooting error codes
- Wiring diagrams and specifications
- System testing procedures

Please ask a specific question about Notifier fire alarm systems.`;
        }

        resolve(response);
      }, 1200);
    });
  };

  const handleSearch = async (query: string) => {
    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: query,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setIsLoading(true);

    try {
      const response = await simulateNotifierResponse(query);
      
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'ai',
        content: response.content,
        timestamp: new Date(),
        citations: response.citations
      };

      setMessages(prev => [...prev, aiMessage]);
    } catch (error) {
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'ai',
        content: 'I cannot answer that based on the current Notifier documentation. Please try asking about specific Notifier system programming or troubleshooting topics.',
        timestamp: new Date()
      };

      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Notifier System Help
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Programming guides, troubleshooting steps, and technical support for Notifier fire alarm systems
          </p>
        </div>

        {/* Search Bar */}
        <div className="mb-8">
          <SearchBar
            onSearch={handleSearch}
            isLoading={isLoading}
            placeholder="Ask about Notifier programming, wiring, troubleshooting..."
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Sidebar - Quick Reference */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-sm p-6 sticky top-8">
              <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Reference</h2>
              
              {/* Category Filter */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Filter by Category
                </label>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-fire-500 focus:border-transparent"
                >
                  {categories.map(category => (
                    <option key={category.value} value={category.value}>
                      {category.label}
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-4">
                <div className="border-b border-gray-200 pb-4">
                  <h3 className="font-medium text-gray-900 mb-2">Common Issues</h3>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• SLC Loop Troubles</li>
                    <li>• Device Programming</li>
                    <li>• NAC Circuit Faults</li>
                    <li>• System Error Codes</li>
                  </ul>
                </div>

                <div className="border-b border-gray-200 pb-4">
                  <h3 className="font-medium text-gray-900 mb-2">Panel Models</h3>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• NFS2-3030</li>
                    <li>• NFS-320</li>
                    <li>• NFS2-640</li>
                    <li>• FSP-951</li>
                  </ul>
                </div>

                <div>
                  <h3 className="font-medium text-gray-900 mb-2">Resources</h3>
                  <ul className="text-sm text-gray-600 space-y-1">
                    <li>• Installation Manuals</li>
                    <li>• Programming Guides</li>
                    <li>• Wiring Diagrams</li>
                    <li>• Technical Bulletins</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Chat Interface */}
            {messages.length > 0 && (
              <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">AI Assistant Responses</h2>
                <div className="space-y-6 max-h-96 overflow-y-auto">
                  {messages.map((message) => (
                    <ChatMessage key={message.id} message={message} />
                  ))}
                  {isLoading && (
                    <div className="flex justify-start">
                      <div className="flex items-start space-x-3">
                        <div className="w-10 h-10 rounded-full bg-gray-600 flex items-center justify-center">
                          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                        </div>
                        <div className="bg-white border border-gray-200 rounded-2xl px-6 py-4">
                          <div className="text-gray-500">Searching Notifier documentation...</div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Troubleshooting Guides */}
            <div className="space-y-6">
              <h2 className="text-2xl font-semibold text-gray-900">
                Troubleshooting Guides
                {selectedCategory !== 'all' && (
                  <span className="text-lg font-normal text-gray-600 ml-2">
                    - {categories.find(c => c.value === selectedCategory)?.label}
                  </span>
                )}
              </h2>

              {filteredGuides.map((guide) => (
                <div key={guide.id} className="bg-white rounded-xl shadow-sm p-6 hover:shadow-md transition-shadow">
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0">
                      <div className="w-12 h-12 rounded-lg bg-fire-100 flex items-center justify-center">
                        <guide.icon className="h-6 w-6 text-fire-600" />
                      </div>
                    </div>
                    
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">{guide.title}</h3>
                      <p className="text-gray-600 mb-4">{guide.description}</p>
                      
                      <div className="mb-4">
                        <h4 className="font-medium text-gray-900 mb-2">Steps:</h4>
                        <ol className="list-decimal list-inside space-y-1 text-sm text-gray-700">
                          {guide.steps.map((step, index) => (
                            <li key={index}>{step}</li>
                          ))}
                        </ol>
                      </div>
                      
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center space-x-2 text-gray-500">
                          <BookOpen className="h-4 w-4" />
                          <span>{guide.relatedManual}</span>
                        </div>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          guide.category === 'programming' ? 'bg-blue-100 text-blue-800' :
                          guide.category === 'troubleshooting' ? 'bg-red-100 text-red-800' :
                          guide.category === 'wiring' ? 'bg-green-100 text-green-800' :
                          'bg-gray-100 text-gray-800'
                        }`}>
                          {guide.category}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotifierHelpPage;