import React, { useState } from 'react';
import { Play, Download, RotateCcw, CheckCircle, XCircle, Award } from 'lucide-react';

interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  difficulty: 'easy' | 'medium' | 'hard';
  chapter: string;
}

interface QuizSettings {
  chapter: string;
  questionCount: number;
  difficulty: 'easy' | 'medium' | 'hard' | 'mixed';
}

const QuizGeneratorPage: React.FC = () => {
  const [quizSettings, setQuizSettings] = useState<QuizSettings>({
    chapter: 'all',
    questionCount: 10,
    difficulty: 'mixed'
  });
  
  const [currentQuiz, setCurrentQuiz] = useState<QuizQuestion[]>([]);
  const [userAnswers, setUserAnswers] = useState<{ [key: string]: number }>({});
  const [showResults, setShowResults] = useState(false);
  const [quizStarted, setQuizStarted] = useState(false);

  const chapters = [
    { value: 'all', label: 'All Chapters' },
    { value: '3', label: 'Chapter 3 - Definitions' },
    { value: '10', label: 'Chapter 10 - Fundamentals' },
    { value: '14', label: 'Chapter 14 - Inspection, Testing, and Maintenance' },
    { value: '17', label: 'Chapter 17 - Initiating Devices' },
    { value: '18', label: 'Chapter 18 - Notification Appliances' },
    { value: '21', label: 'Chapter 21 - Emergency Communications Systems' },
    { value: '23', label: 'Chapter 23 - Protected Premises Fire Alarm Systems' }
  ];

  const sampleQuestions: QuizQuestion[] = [
    {
      id: '1',
      question: 'What is the definition of a "Fire Alarm System" according to NFPA 72?',
      options: [
        'A system that detects fire and activates sprinklers',
        'A system or portion of a combination system that consists of components and circuits arranged to monitor and annunciate the status of fire alarm or supervisory signal-initiating devices',
        'An emergency communication system only',
        'A water-based suppression system'
      ],
      correctAnswer: 1,
      explanation: 'According to NFPA 72-2022, Section 3.3.98, a fire alarm system is defined as a system or portion of a combination system that consists of components and circuits arranged to monitor and annunciate the status of fire alarm or supervisory signal-initiating devices.',
      difficulty: 'easy',
      chapter: '3'
    },
    {
      id: '2',
      question: 'What is the maximum spacing between manual fire alarm boxes on the same floor?',
      options: [
        '100 feet (30 m)',
        '150 feet (46 m)',
        '200 feet (61 m)',
        '300 feet (91 m)'
      ],
      correctAnswer: 2,
      explanation: 'NFPA 72-2022, Section 17.14.9 states that additional manual fire alarm boxes shall be installed so that the travel distance to the nearest manual fire alarm box does not exceed 200 feet (61 m).',
      difficulty: 'medium',
      chapter: '17'
    },
    {
      id: '3',
      question: 'How often should fire alarm systems be inspected according to NFPA 72?',
      options: [
        'Monthly',
        'Quarterly',
        'Semi-annually',
        'Annually'
      ],
      correctAnswer: 3,
      explanation: 'NFPA 72-2022, Table 14.4.3.2 requires that fire alarm systems receive annual inspection, though some components may require more frequent inspection.',
      difficulty: 'medium',
      chapter: '14'
    }
  ];

  const generateQuiz = () => {
    // In a real application, this would filter based on settings
    const filteredQuestions = sampleQuestions.slice(0, quizSettings.questionCount);
    setCurrentQuiz(filteredQuestions);
    setUserAnswers({});
    setShowResults(false);
    setQuizStarted(true);
  };

  const handleAnswerSelect = (questionId: string, answerIndex: number) => {
    if (!showResults) {
      setUserAnswers(prev => ({ ...prev, [questionId]: answerIndex }));
    }
  };

  const submitQuiz = () => {
    setShowResults(true);
  };

  const resetQuiz = () => {
    setCurrentQuiz([]);
    setUserAnswers({});
    setShowResults(false);
    setQuizStarted(false);
  };

  const calculateScore = () => {
    let correct = 0;
    currentQuiz.forEach(question => {
      if (userAnswers[question.id] === question.correctAnswer) {
        correct++;
      }
    });
    return { correct, total: currentQuiz.length, percentage: Math.round((correct / currentQuiz.length) * 100) };
  };

  const downloadResults = () => {
    const score = calculateScore();
    const results = `Fire Alarm Quiz Results
Generated: ${new Date().toLocaleString()}
Settings: Chapter ${quizSettings.chapter}, ${quizSettings.questionCount} questions, ${quizSettings.difficulty} difficulty

Score: ${score.correct}/${score.total} (${score.percentage}%)

Questions and Answers:
${currentQuiz.map((q, index) => `
${index + 1}. ${q.question}
Your Answer: ${q.options[userAnswers[q.id]] || 'Not answered'}
Correct Answer: ${q.options[q.correctAnswer]}
${userAnswers[q.id] === q.correctAnswer ? '✓ Correct' : '✗ Incorrect'}
Explanation: ${q.explanation}
`).join('\n')}`;

    const blob = new Blob([results], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `fire-alarm-quiz-results-${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  if (!quizStarted) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Quiz Generator
            </h1>
            <p className="text-lg text-gray-600">
              Test your knowledge with custom quizzes from NFPA 72
            </p>
          </div>

          <div className="bg-white rounded-xl shadow-sm p-8">
            <h2 className="text-2xl font-semibold text-gray-900 mb-6">Quiz Settings</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Chapter Selection
                </label>
                <select
                  value={quizSettings.chapter}
                  onChange={(e) => setQuizSettings(prev => ({ ...prev, chapter: e.target.value }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-fire-500 focus:border-transparent"
                >
                  {chapters.map(chapter => (
                    <option key={chapter.value} value={chapter.value}>
                      {chapter.label}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Number of Questions
                </label>
                <select
                  value={quizSettings.questionCount}
                  onChange={(e) => setQuizSettings(prev => ({ ...prev, questionCount: parseInt(e.target.value) }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-fire-500 focus:border-transparent"
                >
                  <option value={5}>5 Questions</option>
                  <option value={10}>10 Questions</option>
                  <option value={15}>15 Questions</option>
                  <option value={20}>20 Questions</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Difficulty Level
                </label>
                <select
                  value={quizSettings.difficulty}
                  onChange={(e) => setQuizSettings(prev => ({ ...prev, difficulty: e.target.value as any }))}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-fire-500 focus:border-transparent"
                >
                  <option value="mixed">Mixed Difficulty</option>
                  <option value="easy">Easy</option>
                  <option value="medium">Medium</option>
                  <option value="hard">Hard</option>
                </select>
              </div>
            </div>

            <button
              onClick={generateQuiz}
              className="w-full bg-fire-600 hover:bg-fire-700 text-white px-8 py-4 rounded-lg font-semibold transition-colors flex items-center justify-center space-x-2"
            >
              <Play className="h-5 w-5" />
              <span>Generate Quiz</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  const score = showResults ? calculateScore() : null;

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Quiz Header */}
        <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">
                NFPA 72 Quiz - {chapters.find(c => c.value === quizSettings.chapter)?.label}
              </h1>
              <p className="text-gray-600">
                {quizSettings.questionCount} questions • {quizSettings.difficulty} difficulty
              </p>
            </div>
            <div className="flex space-x-2">
              {showResults && (
                <button
                  onClick={downloadResults}
                  className="flex items-center space-x-2 px-4 py-2 bg-fire-600 text-white rounded-lg hover:bg-fire-700 transition-colors"
                >
                  <Download className="h-4 w-4" />
                  <span>Download</span>
                </button>
              )}
              <button
                onClick={resetQuiz}
                className="flex items-center space-x-2 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
              >
                <RotateCcw className="h-4 w-4" />
                <span>New Quiz</span>
              </button>
            </div>
          </div>
        </div>

        {/* Results Summary */}
        {showResults && score && (
          <div className="bg-white rounded-xl shadow-sm p-6 mb-8">
            <div className="text-center">
              <Award className={`h-16 w-16 mx-auto mb-4 ${score.percentage >= 80 ? 'text-green-500' : score.percentage >= 60 ? 'text-yellow-500' : 'text-red-500'}`} />
              <h2 className="text-3xl font-bold text-gray-900 mb-2">
                {score.correct}/{score.total} ({score.percentage}%)
              </h2>
              <p className="text-lg text-gray-600">
                {score.percentage >= 80 ? 'Excellent work!' : score.percentage >= 60 ? 'Good job!' : 'Keep studying!'}
              </p>
            </div>
          </div>
        )}

        {/* Quiz Questions */}
        <div className="space-y-6">
          {currentQuiz.map((question, index) => (
            <div key={question.id} className="bg-white rounded-xl shadow-sm p-6">
              <div className="flex items-start justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900 pr-4">
                  {index + 1}. {question.question}
                </h3>
                <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                  question.difficulty === 'easy' ? 'bg-green-100 text-green-800' :
                  question.difficulty === 'medium' ? 'bg-yellow-100 text-yellow-800' :
                  'bg-red-100 text-red-800'
                }`}>
                  {question.difficulty}
                </span>
              </div>

              <div className="space-y-3">
                {question.options.map((option, optionIndex) => {
                  const isSelected = userAnswers[question.id] === optionIndex;
                  const isCorrect = optionIndex === question.correctAnswer;
                  const showCorrectness = showResults;

                  return (
                    <button
                      key={optionIndex}
                      onClick={() => handleAnswerSelect(question.id, optionIndex)}
                      disabled={showResults}
                      className={`w-full text-left p-4 rounded-lg border-2 transition-all ${
                        showCorrectness
                          ? isCorrect
                            ? 'border-green-500 bg-green-50'
                            : isSelected
                            ? 'border-red-500 bg-red-50'
                            : 'border-gray-200 bg-white'
                          : isSelected
                          ? 'border-fire-500 bg-fire-50'
                          : 'border-gray-200 bg-white hover:border-gray-300 hover:bg-gray-50'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span>{option}</span>
                        {showCorrectness && (
                          <div>
                            {isCorrect && <CheckCircle className="h-5 w-5 text-green-500" />}
                            {isSelected && !isCorrect && <XCircle className="h-5 w-5 text-red-500" />}
                          </div>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>

              {showResults && (
                <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                  <p className="text-sm text-gray-700">
                    <strong>Explanation:</strong> {question.explanation}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Submit Button */}
        {!showResults && (
          <div className="text-center mt-8">
            <button
              onClick={submitQuiz}
              disabled={Object.keys(userAnswers).length !== currentQuiz.length}
              className="bg-fire-600 hover:bg-fire-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white px-8 py-3 rounded-lg font-semibold transition-colors"
            >
              Submit Quiz
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default QuizGeneratorPage;