
import React, { useState } from 'react';
import SearchBar from '../components/SearchBar';

const AskAIPage = () => {
  const [results, setResults] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const handleSearch = (query: string) => {
    setIsLoading(true);
    setTimeout(() => {
      setResults([
        `Result for "${query}" from NFPA 72`,
        `Result for "${query}" from Notifier Manuals`,
      ]);
      setIsLoading(false);
    }, 1000);
  };

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Ask AI (NFPA 72 & Notifier)</h1>
      <SearchBar onSearch={handleSearch} isLoading={isLoading} />
      <div className="mt-6">
        {isLoading ? (
          <p className="text-gray-500">Searching...</p>
        ) : (
          results.map((res, i) => (
            <div key={i} className="p-4 mb-2 bg-gray-100 dark:bg-gray-800 rounded shadow">
              {res}
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default AskAIPage;
