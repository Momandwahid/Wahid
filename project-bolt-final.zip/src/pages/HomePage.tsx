import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, BookOpen, Brain, HelpCircle, Settings, Shield, Users, Zap } from 'lucide-react';
import SearchBar from '../components/SearchBar';

const HomePage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    // Redirect to Ask AI page with query
    window.location.href = `/ask-ai?q=${encodeURIComponent(query)}`;
  };

  const features = [
    {
      icon: Brain,
      title: 'AI Assistant',
      description: 'Get instant answers from NFPA 72 and Notifier documentation',
      link: '/ask-ai',
      color: 'fire'
    },
    {
      icon: HelpCircle,
      title: 'Quiz Generator',
      description: 'Test your knowledge with custom quizzes by chapter or topic',
      link: '/quiz',
      color: 'blue'
    },
    {
      icon: Settings,
      title: 'Notifier Help',
      description: 'Troubleshooting guides and system programming assistance',
      link: '/notifier-help',
      color: 'green'
    },
    {
      icon: Shield,
      title: 'Admin Panel',
      description: 'Manage documents and system configuration (Admin only)',
      link: '/admin',
      color: 'purple'
    }
  ];

  const stats = [
    { number: '800+', label: 'NFPA 72 Sections', icon: BookOpen },
    { number: '50+', label: 'Notifier Manuals', icon: Settings },
    { number: '24/7', label: 'AI Availability', icon: Zap },
    { number: '100%', label: 'Code Accuracy', icon: Shield }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-fire-600 to-fire-700 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Fire Alarm AI Assistant
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-fire-100">
              Your 24/7 study and training tool for NFPA 72 & Notifier Fire Alarm Systems
            </p>
            
            {/* Main Search Bar */}
            <div className="max-w-3xl mx-auto mb-8">
              <SearchBar
                onSearch={handleSearch}
                placeholder="Ask about NFPA 72 definitions, Notifier programming, or fire alarm codes..."
                className="transform hover:scale-105 transition-transform"
              />
            </div>

            <div className="flex flex-wrap justify-center gap-4">
              <Link
                to="/ask-ai"
                className="bg-white text-fire-600 px-8 py-3 rounded-full font-semibold hover:bg-gray-100 transition-colors flex items-center space-x-2"
              >
                <span>Start Asking Questions</span>
                <ArrowRight className="h-5 w-5" />
              </Link>
              <Link
                to="/quiz"
                className="border-2 border-white text-white px-8 py-3 rounded-full font-semibold hover:bg-white hover:text-fire-600 transition-colors"
              >
                Take a Quiz
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="flex justify-center mb-4">
                  <stat.icon className="h-8 w-8 text-fire-600" />
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-2">{stat.number}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Everything You Need for Fire Alarm Training
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Comprehensive tools and resources for mastering NFPA 72 and Notifier systems
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Link
                key={index}
                to={feature.link}
                className="bg-white rounded-xl p-8 shadow-sm hover:shadow-lg transition-all duration-300 hover:-translate-y-1 group"
              >
                <div className={`w-16 h-16 rounded-lg mb-6 flex items-center justify-center bg-${feature.color}-100 group-hover:bg-${feature.color}-200 transition-colors`}>
                  <feature.icon className={`h-8 w-8 text-${feature.color}-600`} />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-600 mb-4">{feature.description}</p>
                <div className="flex items-center text-fire-600 font-medium group-hover:text-fire-700">
                  <span>Learn more</span>
                  <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Users className="h-16 w-16 text-fire-500 mx-auto mb-6" />
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Master Fire Alarm Systems?
          </h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Join thousands of technicians, engineers, and inspectors who use our AI assistant for training and reference.
          </p>
          <Link
            to="/ask-ai"
            className="bg-fire-600 hover:bg-fire-700 text-white px-8 py-4 rounded-full text-lg font-semibold transition-colors inline-flex items-center space-x-2"
          >
            <span>Get Started Now</span>
            <ArrowRight className="h-5 w-5" />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;